var db = {
    dados: [
        {
            titulo: 'A ciência da procrastinação',
            link: 'https://super.abril.com.br/comportamento/a-ciencia-da-procrastinacao/',
            conteudo:'Ela é uma luta entre duas partes do cérebro. Mas essa batalha pode ser vencida. Veja como.'
        }, {
            titulo: 'Organizar a rotina diária e equilibrar trabalho e descanso?',
            link: 'https://direcional.com.br/blog/estilo-de-vida/organizar-rotina-diaria/',
            conteudo:'Produtividade e bem-estar são alguns dos benefícios de manter uma rotina diária organizada, em especial, no trabalho em casa. Saiba mais!'
        }, {
            titulo: 'Produtividade',
            link: 'https://www.napratica.org.br/produtividade-como-ser-mais-produtivo/',
            conteudo:'Tudo que você precisa saber para se tornar mais produtivo'
        }, {
            titulo: 'Produtividade no trabalho',
            link: 'https://blog.solides.com.br/produtividade',
            conteudo:'guia completo com conceito, dicas e indicadores'
        }
    ]
}