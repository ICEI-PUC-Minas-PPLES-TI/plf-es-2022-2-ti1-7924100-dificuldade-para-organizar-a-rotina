var db = {
  dados: [
    {
      titulo: '5 PASSOS para CRIAR SUA ROTINA e SER MAIS PRODUTIVO!',
      link: 'https://www.youtube.com/embed/--eFE_typ3w',
    }, {
      titulo: 'Como parar de procrastinar usando a regra dos 70%',
      link: 'https://www.youtube.com/embed/RE7wfmKoHi8',
    }, {
      titulo: 'COMO ORGANIZAR O SEU PLANEJAMENTO E ROTINA | Método GTD',
      link: 'https://www.youtube.com/embed/B1VSNNwqMAM',
    }, {
      titulo: 'Como organizar seu dia igual Elon Musk e Bill Gates.',
      link: 'https://www.youtube.com/embed/4IRo-sgQB44',
    }, {
      titulo: 'COMO ESTUDAR E TRABALHAR SEM PERDER O FOCO',
      link: 'https://www.youtube.com/embed/PWkNNqBF30w',
    }, {
      titulo: 'Gestão de tempo e planejamento',
      link: 'https://www.youtube.com/embed/PzUZsoyMXuY',
    }
  ]
}